//var DB = require('./managedb.js');
const EXPRESS = require('express');
const BODY_PARSER = require('body-parser');
const SERVER = EXPRESS();
SERVER.use(BODY_PARSER.json());
SERVER.use(BODY_PARSER.urlencoded({limit: '15mb', extended: true }));
const path = require('path');
const HTTP = require('http');
const FS = require('fs');

SERVER.use('/static', EXPRESS.static(path.join(__dirname, 'public')))
SERVER.set("view engine", "ejs"); // Para renderizar variables dentro de HTML

SERVER.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'index.html'));
});

var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
//mongoose.connect('mongodb://fmgordillo:facu1995@mytestingcluster-shard-00-00-le3uz.mongodb.net:27017,mytestingcluster-shard-00-01-le3uz.mongodb.net:27017,mytestingcluster-shard-00-02-le3uz.mongodb.net:27017/test?ssl=true&replicaSet=MyTestingCluster-shard-0&authSource=admin', {useMongoClient: true});
mongoose.connect('mongodb://localhost/repuestos', {useMongoClient: true});

var repuestoSchema = mongoose.Schema({
    codigo: Number,
    nombre: String,
    precio: String,
    stock: String
});

var Repuesto = mongoose.model('Repuesto', repuestoSchema);

mongoose.connection.on('error', function (err){
    console.log("Error en conexión con Mongo");
});

mongoose.connection.on('open', function(err) {
    console.log('connected mongo!');

    SERVER.listen(process.env.PORT || 3000, function () {
        console.log('API andando con express...');
    });

    SERVER.get('/lista', function (req, res) {
        Repuesto.find(function(err,doc){
            res.render('lista', { elementos: doc });
        });
    });

    SERVER.post('/repuestos', function (req, res) {
        console.log(req.body.codigo);
        var repuesto = new Repuesto({
            codigo: req.body.codigo,
            nombre: req.body.nombre,
            precio: req.body.precio,
            stock: req.body.stock});

        repuesto.save(function () {
            res.send("Registro Insertado Correctamente!");
        });
    });

    SERVER.post('/delete', function (req, res) {
        var repuesto = new Repuesto ({
            codigo: req.body.codigo_del});
            repuesto.remove({codigo: req.body.codigo_del},function (err,doc) {
            if (err) {
                res.send("Hubo un error al intentar eliminar el producto");
            }else {
                    res.send("Su registro se eliminó correctamente");
                }
        });
    });
});

/*
var stock_schema = new Schema(stockSchemaJSON);
var Repuesto = mongoose.model("repuestos", stock_schema);

var stockSchemaJSON = {
    codigo: Number,
    nombre: String,
    precio: String,
    stock: String
};



SERVER.post('/', function (req, res) {
    console.log(req.body.codigo);
    var repuesto = new Repuesto({
        codigo: req.body.codigo,
        nombre: req.body.nombre,
        precio: req.body.precio,
        stock: req.body.stock});
    repuesto.save(function () {
        console.log(req.body)
        res.send("Insert ok");
    });
});
*/
/*
SERVER.post('/', function (req, res) {
    var respuesta;
    console.log("Req");
    console.log(req.body);
    res = getElementById("DivContenedor");
    var repuesto = new Repuesto({codigo: req.body.codigo,
        nombre: req.body.nombre,
        precio: req.body.precio,
        stock: req.body.stock});
        //res.send("Varible ", res.getElementById("codigo").innerHTML);
    repuesto.save(function () {
        res.send("Insert ok");
    });
});

Para mostrar un codigo en particular
console.log("codigo:" + doc[0].codigo + " is equal to " + doc[0].nombre
             )

*/






