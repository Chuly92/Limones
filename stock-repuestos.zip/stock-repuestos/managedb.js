var mongoose = require('mongoose');
var url = 'mongodb://fmgordillo:facu1995@mytestingcluster-shard-00-00-le3uz.mongodb.net:27017,mytestingcluster-shard-00-01-le3uz.mongodb.net:27017,mytestingcluster-shard-00-02-le3uz.mongodb.net:27017/test?ssl=true&replicaSet=MyTestingCluster-shard-0&authSource=admin';

module.exports = mongoose.model('Repuesto', {
    codigo: Number,
    nombre: String,
    precio: String,
    stock: String
});

// FUNCION GLOBAL
exports.findAll = function (req, res){
    Repuesto.find(
        function(err, persona) {
            if (err)
                res.send(err)
            res.json(persona); // devuelve todas las Personas en JSON
        }
    );
};

/*
//Buscar todos los elementos de la colección repuestos
var findDocuments = function(db, callback) {
    var collection = db.collection('repuestos');
        collection.find({}).toArray(function(err, docs) {
            assert.equal(err, null);
            console.log("Found the following records");
            //console.log(docs)
        //callback(callback);
        callback(docs);
    });
};

// FUNCION GLOBAL
exports.ListarRepuestos = function() {
    MongoClient.connect(url,function(err, db) {
        assert.equal(null, err);
        console.log("Connected successfully to server");
        findDocuments(db, function(res) {
            console.log(res);
            db.close();
        });
    });
};

//Insertar repuestos de forma estática (hardcoded)
var insertDocuments = function(db, callback) {
    var collection = db.collection('repuestos');
    collection.insertMany([
        {codigo: 1, nombre: 'Embrague Sachs VW Gol/Senda/Saveiro/Polo', precio: '1850.00', stock: '10'},
        {codigo: 2, nombre: 'Amortiguador VW Gol/Senda/Saveiro', precio: '550,00', stock: '8'},
        {codigo: 3, nombre: 'Óptica Delantera x2 VW Gol G3 00-05', precio: '1200,90', stock: '24'},
        {codigo: 4, nombre: 'Batería Moura 12x65', precio: '2200,00', stock: '15'},
        {codigo: 5, nombre: 'Correa Distribución VW Gol/Senda/Saveiro', precio: '1850,00', stock: '17'},
        {codigo: 6, nombre: 'Óptica Trasera x2 VW Gol G3 00-05', precio: '1320,00', stock: '10'},
        {codigo: 7, nombre: 'Bujías Sachs x2 para VW Gol/Senda 89-95', precio: '250,00', stock: '4'},
        {codigo: 8, nombre: 'Radiador VW Gacel 88-95', precio: '3000,00', stock: '8'},
        {codigo: 9, nombre: 'Limpia parabrisas trasero VW Gol/Fox', precio: '320,00', stock: '35'},
        {codigo: 10, nombre: 'Limpia Inyectores Bardahl x Litro', precio: '420,90', stock: '5'}
    ], function(err, result) {
        assert.equal(err, null);
        assert.equal(10, result.result.n);
        assert.equal(10, result.ops.length);
        console.log("Inserted successfull into the collection");
        callback(result);
    });
}

//Eliminar un documento de forma estática (hardcoded)
var removeDocument = function(db, callback) {
    var collection = db.collection('repuestos');
    collection.deleteOne({codigo : 2}, function(err, result) {
        assert.equal(err, null);
        assert.equal(1, result.result.n);
        console.log("Removed the document");
        callback(result);
    });
}



// Use connect method to connect to the server
exports.InsertarRepuestos = function () {
    MongoClient.connect(url,function(err, db) {
        assert.equal(null, err);
        console.log("Connected successfully to server");
        insertDocuments(db, function () {
            db.close();
        });
    });
};

//SACAR
/*MongoClient.connect(url, function(err, db) {
    assert.equal(null, err);
    console.log("Connected correctly to server");
    var findDocuments = function(db, callback) {
        var collection = db.collection('repuestos');
        collection.find({}).toArray(function(err, docs) {
            assert.equal(err, null);
            console.log("Found the following records");
            console.log(docs)
            callback(docs);
        });
    };
});*/

//SACAR



