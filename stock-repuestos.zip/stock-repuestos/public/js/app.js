var app = angular.module('Stock', []);
var successCallback = 200;
var errorCallback = 400;

app.controller('StockController', ['$scope', '$http', function($scope, $http) {

$http.get('/products').then(successCallback, errorCallback);
     $scope.greeting = 'Hola!';
}]);





